# 💰 Day Family Budget Tracker (PWA)

A Progressive Web App for tracking your household budget, renovation spending, debts, and goals.

## Quick Start

1. **Unzip** this folder anywhere on your computer
2. **Open a terminal** in the folder
3. **Run the server:**
   ```
   python3 serve.py
   ```
4. **Open on your phone** — connect to the same Wi-Fi, then visit:
   ```
   https://<YOUR_IP>:8443
   ```
   (The server will show you the exact URL)

5. **Install as an app:**
   - **iPhone (Safari):** Tap Share (↑) → "Add to Home Screen"
   - **Android (Chrome):** Tap the install banner, or Menu (⋮) → "Install app"

## Certificate Warning

Your browser will show a security warning because the certificate is self-signed.
This is normal and safe — it's YOUR server on YOUR home network.

- **Safari:** Tap "Show Details" → "visit this website" → "Visit Website"
- **Chrome:** Tap "Advanced" → "Proceed to (IP address)"

## Syncing Between Devices

Each device stores its own data in localStorage. To sync:

1. Go to **Settings → Export Data** on one device
2. Transfer the JSON file to the other device
3. Go to **Settings → Import Data** on the other device

## Moving to GitHub Pages Later

When you're ready to host this publicly:

1. Create a GitHub repo
2. Push all files (index.html, sw.js, manifest.json, icons/)
3. Enable GitHub Pages in repo Settings
4. Share the `https://yourusername.github.io/repo-name` URL

No changes needed — it works the same way on GitHub Pages!

## Files

```
├── index.html       ← Main app
├── manifest.json    ← PWA manifest (name, icons, theme)
├── sw.js            ← Service worker (offline caching)
├── serve.py         ← Local HTTPS server
├── icons/
│   ├── icon-192x192.png
│   └── icon-512x512.png
└── README.md        ← This file
```

## Requirements

- Python 3 (pre-installed on macOS/Linux)
- OpenSSL (pre-installed on macOS/Linux)
- Windows: Install Python from python.org, OpenSSL from slproweb.com
