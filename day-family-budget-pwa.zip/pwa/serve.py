#!/usr/bin/env python3
"""
Day Family Budget Tracker — Local Network Server

USAGE:
  python3 serve.py

Then on any device on your Wi-Fi, open:
  https://<YOUR_IP>:8443

To install on iPhone/Android:
  1. Open the URL in Safari (iPhone) or Chrome (Android)
  2. iPhone:  Tap Share → "Add to Home Screen"
  3. Android: Tap the install banner, or Menu → "Install app"

NOTE: The browser will warn about the self-signed certificate.
  - iPhone/Safari:  Tap "Show Details" → "visit this website" → "Visit Website"
  - Android/Chrome:  Tap "Advanced" → "Proceed to <IP>"
  This is safe — it's YOUR server on YOUR network.
"""

import http.server
import ssl
import os
import socket
import subprocess
import sys

PORT = 8443
DIR = os.path.dirname(os.path.abspath(__file__))

def get_local_ip():
    """Get local network IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "localhost"

def generate_cert():
    """Generate a self-signed SSL certificate for HTTPS."""
    cert_file = os.path.join(DIR, "cert.pem")
    key_file = os.path.join(DIR, "key.pem")
    
    if os.path.exists(cert_file) and os.path.exists(key_file):
        print("✅ Using existing SSL certificate")
        return cert_file, key_file
    
    print("🔐 Generating self-signed SSL certificate...")
    ip = get_local_ip()
    
    try:
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-keyout", key_file, "-out", cert_file,
            "-days", "365", "-nodes",
            "-subj", f"/CN={ip}",
            "-addext", f"subjectAltName=IP:{ip},IP:127.0.0.1,DNS:localhost"
        ], check=True, capture_output=True)
        print("✅ SSL certificate generated")
    except FileNotFoundError:
        print("❌ OpenSSL not found. Install it:")
        print("   macOS:  brew install openssl")
        print("   Ubuntu: sudo apt install openssl")
        print("   Windows: download from https://slproweb.com/products/Win32OpenSSL.html")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"❌ Certificate generation failed: {e.stderr.decode()}")
        sys.exit(1)
    
    return cert_file, key_file

def main():
    os.chdir(DIR)
    
    cert_file, key_file = generate_cert()
    ip = get_local_ip()
    
    handler = http.server.SimpleHTTPRequestHandler
    
    # Suppress noisy SSL error logs from browsers
    class QuietHandler(handler):
        def log_message(self, format, *args):
            # Only log actual page requests, not SSL errors
            if len(args) >= 1 and isinstance(args[0], str) and args[0].startswith(('GET', 'POST')):
                super().log_message(format, *args)
    
    server = http.server.HTTPServer(("0.0.0.0", PORT), QuietHandler)
    
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert_file, key_file)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    
    print()
    print("=" * 56)
    print("  💰 Day Family Budget Tracker")
    print("=" * 56)
    print()
    print(f"  🌐 Open on this computer:")
    print(f"     https://localhost:{PORT}")
    print()
    print(f"  📱 Open on phone (same Wi-Fi):")
    print(f"     https://{ip}:{PORT}")
    print()
    print(f"  📲 To install as app:")
    print(f"     iPhone:  Share → Add to Home Screen")
    print(f"     Android: Tap install banner or ⋮ → Install")
    print()
    print(f"  ⚠️  Accept the certificate warning — it's safe!")
    print()
    print("=" * 56)
    print("  Press Ctrl+C to stop the server")
    print("=" * 56)
    print()
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Server stopped.")
        server.server_close()

if __name__ == "__main__":
    main()
